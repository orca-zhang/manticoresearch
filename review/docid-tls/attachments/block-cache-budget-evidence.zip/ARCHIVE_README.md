# Cache budgets and reader-TLS combination evidence

Read BLOCK_CACHE_BUDGETS_2026-11-13.md first. Its three comparisons are old/new
shared cache at equal budget, same-binary cache off/on, and incremental reader
TLS at equal budget. New raw data lives under evidence/2026-11-13/:
block-cache-budgets/, tls-block-cache-budgets/, and cache-budgets-summary/.
Each phase retains the exact measured driver snapshot, all completed samples,
commands, pre-run plan and load records. Public reproduction helpers are under
repro/2026-11-13/. Existing engine source/test/build evidence and historical
reports are included to retain context; no executables or object files are added.

PR #5042 source remains TLS-free at 376fbf9. PR #5045 remains TLS-only at
019868e9. The combined benchmark is evidence, not a production dependency.
Native DocID and SQL query-result caches are off in all new budget arms.
CI repairs are pushed, but upstream still requires maintainer workflow approval.

Older downloadable attachments referenced in reports remain online; nested
download ZIPs are omitted. ARCHIVE_SHA256.json hashes every member except itself.
