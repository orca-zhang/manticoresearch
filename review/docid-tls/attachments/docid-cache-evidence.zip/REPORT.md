# docid-cache measurements

## 1. DocID cache-line directory isolation

Reference: fixed-16-child native cache prototype with stack scratch. Candidate:
current adaptive native cache with the same scratch policy. This is a comparison
within the new cache, not against upstream compressed lookup and not SQL QPS.
Intel N100 / 64 B cache lines / GCC 11.4 `-O3`, 100k and 1M documents, five
rotated rounds with five thread-CPU samples/case. Batch API calls have 16 probes.

| Order | Documents | Batch gain: 0 / 50 / 100% misses | Scalar gain: 0 / 50 / 100% misses |
| --- | ---: | --- | --- |
| sorted | 100,000 | +22.22% / +24.39% / +25.74% | +27.64% / +29.60% / +30.21% |
| sorted | 1,000,000 | +18.82% / +19.85% / +19.56% | +40.64% / +35.53% / +31.65% |
| random | 100,000 | +25.08% / +20.76% / +27.17% | +20.44% / +27.29% / +25.73% |
| random | 1,000,000 | +12.58% / +11.05% / +14.96% | +53.60% / +55.55% / +43.30% |

The 128 B Apple M4 Pro keeps 16 children; no consistent improvement is established
there (batch samples span -4.93% to +3.60%). No current Linux/N100 SQL QPS
measurement exists for directory adaptation. The exact source hashes, compiler
manifests and full negative/control data are included in `evidence/stack-scratch-*`.
The raw historical three-arm run also contains temporary-array TLS; only the
fixed16+stack and adaptive+stack arms contribute to this directory comparison.

Memory at 1M documents:

| Host | Fixed16 prototype | Adaptive candidate | Difference |
| --- | ---: | ---: | ---: |
| N100 / 64 B | 12,133,887 B | 12,143,295 B | +9,408 B (+0.078%) |
| M4 Pro / 128 B | 12,134,015 B | 12,134,015 B | 0 |

These are requested allocation bytes, not RSS. The whole DocID cache is extra
memory beside existing mapped data (about 11.58 MiB per million entries on N100).
Its default budget is zero; budgets include handles and alignment slack. No
overall memory saving is claimed for alignment or for adding the native cache.

