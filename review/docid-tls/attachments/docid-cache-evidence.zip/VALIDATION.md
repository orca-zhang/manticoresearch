# Local validation environment

Base: 047d2f99522d78e0aa1de7e7dc945a9abe1b673a; MCL:
88b5412a243ab0439957203acfe86c09944280d3. Apple M4 Pro, Clang 21,
RelWithDebInfo -O2. MCL_LOCAL_RUNTIME=OFF, dynamic ICU ON;
Galera/MySQL/PostgreSQL/ODBC/Jieba/RE2/Snowball OFF.
Full UberTest/CLT, Windows and Linux full-engine/SQL CI are not covered here.
No production capacity, tail-latency or process-RSS benefit is claimed.

Fresh independent build: 517/517 GoogleTests passed. SQL lifecycle passed at
0/1 KiB/16 MiB budgets. Focused ASan+UBSan passed 14 cache tests on actual
Apple/128 B, forced64/256 B and actual N100/64 B. Four concurrency cases
passed Apple TSan; these sanitizer runs use the earlier experimental base
and matching module source hashes, not a full-engine sanitizer build.

The full preparation record separately retains a combined-tree first-run JSON
death-test SIGBUS and its 522/522 calibrated rerun. No such failure occurred
in the independent patch validation reported above.
