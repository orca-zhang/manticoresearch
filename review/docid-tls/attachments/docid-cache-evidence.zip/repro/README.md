# Reproduce the DocID directory comparison

Extract this attachment, then from its root run:

```sh
python3 repro/bench_cache_layout.py --output /tmp/docid-layout --rounds 5 --opt-level 3
python3 repro/bench_cache_layout.py --output /tmp/docid-current --rounds 5 --opt-level 3 \
  --candidate /path/to/patched/checkout/src
```

Linux/macOS and a C++17 compiler are required; CXX selects the compiler. The
Apple measurements use --opt-level 2. Both arms have stack scratch; timings are
thread CPU ns/lookup. Matching source pairs and compiler/source manifests are
preserved. Untimed checks verify outputs; batch calls contain 16 probes. The
original archived run also rotated a historical scratch-TLS arm; the report
selects only auto/fixed16+stack and adaptive-stack. This compact runner compares
those two mechanisms, with a different two-arm scheduling order.

Apply the source patch to the stated upstream base, initialize pinned MCL, and
follow upstream build dependencies. Build searchd/gmanticoretest, run the full
GoogleTest suite and then the patched checkout's SQL lifecycle helper:

```sh
cmake --build /path/to/build --target searchd gmanticoretest -j 6
cmake -E chdir /path/to/build src/gtests/gmanticoretest
python3 /path/to/checkout/test/docid-cache/test_integration.py /path/to/build/src/searchd
```

Focused cache sanitizers compile docidlookupcache.cpp and gtests_docidcache.cpp
with C++17, source/GoogleTest include paths, gtest_main/gtest/thread libraries
and -fsanitize=address,undefined -fno-omit-frame-pointer -O1 -g. Use a separate
-fsanitize=thread build for concurrency. The recorded runs are focused coverage.
Directory throughput percentages must not be reported as SQL QPS.
