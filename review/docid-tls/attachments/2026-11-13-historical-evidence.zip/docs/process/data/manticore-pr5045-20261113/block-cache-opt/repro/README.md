# PR #5045 supplemental tests

Compare upstream `047d2f99522d78e0aa1de7e7dc945a9abe1b673a` with exactly the
production changes in PR commit `019868e9f79d1bb2bd1f96dafb88ef20acd45418`.
No DocID prototype or generation sharding is included. All tools use Python's
standard library. The recorded run uses Apple M4 Pro / Apple Clang 21, `-O2`.

`gtests_docstore_readers.cpp` contains the five original PR tests and three
additional public-API cases: concurrent unrelated session churn, reader-budget
refusal followed by creation, and cross-thread creation after a cached null.
Both upstream and TLS implementations must pass all eight tests.

Build two independent binaries with the same dependencies and configuration.
The recorded build uses MCL `88b5412a243ab0439957203acfe86c09944280d3`,
`RelWithDebInfo` with `-DCMAKE_CXX_FLAGS_RELWITHDEBINFO='-O2 -DNDEBUG'` and the same
C flags; debug symbols are omitted to reduce local disk use. Set
`BUILD_TESTING=ON`, `MCL_LOCAL_RUNTIME=OFF`, `WITH_ICU_FORCE_STATIC=OFF`, and disable
Galera, MySQL/PostgreSQL/ODBC sources, Jieba, RE2 and Snowball as in the recorded
configure log. The report's build manifest, configure log and binary hashes
identify the actual inputs. The full GoogleTest suite runs on both binaries.

On macOS, use the matching build's `MANTICORE_*` stack calibration from its
GoogleTest output for both SQL benchmark arms. The values in the archived run
are not portable defaults for a different build or compiler.

`scale_benchmark.py` holds the original query generator fixed at eight clients,
256 rows/query and 20 templates/client while varying 20k/100k/500k/1M/5M rows and
block-cache budgets 0/16/128 MiB (plus 512 MiB at 5M). It reuses the same verified
request/measurement code, records median process RSS, and separates TLS gains at
a fixed budget from gains caused by changing the cache budget. Five count controls
and two A/A controls accompany the 16 data/cache cells. Reader-buffer capacity
remains 8 MiB, and the PR retains its one-entry TLS policy.

Recorded results: [size/cache matrix](../../docs/process/manticore-pr5045-scale-2026-11-13.md)
and [broader workload and correctness checks](../../docs/process/manticore-pr5045-review-2026-11-13.md).

`block-cache-shards.patch` is a separate follow-up experiment on top of the TLS
reader PR. It partitions the shared block cache into at most 16 independently
locked LRU caches, with the sum of their entry budgets equal to the original
budget. Hash tables and mutex metadata add overhead. Cache budgets below 2 MiB
retain one shard. The original cache's block-admission threshold is preserved
through an optional LRU constructor argument; other callers keep their old
threshold. A block still has to fit in its individual shard.
The final variant uses the existing `HashWithSeed`/xxHash helper for the block
key instead of the previous CRC32 chain, reducing the cost of routing and
looking up each cached block. The CRC-only sharding experiment and its repeats
are retained separately in the raw evidence.

For the follow-up, first build the unmodified TLS reader implementation, then
apply the patch and rebuild with identical flags/dependencies. Add
`gtests_docstore_blockcache.cpp` to `src/gtests/` and the `GTESTS_SRC` list in both
builds. The three additional public-API tests cover cache clear and index-key
reuse, eight concurrent readers under eviction pressure, and large fields with
a tiny-cache fallback. `compare_blockcache.py` reuses the verified driver and
existing fixtures to check 15 workloads, including count, cache-off and A/A
controls. In its raw output, `reference` means the unchanged TLS reader build
and `tls` means the block-cache candidate; A/A uses the unchanged build twice.

```sh
python3 scripts/manticore_pr5045/compare_blockcache.py --selfcheck
python3 scripts/manticore_pr5045/compare_blockcache.py TLS_SEARCHD SHARDED_SEARCHD \
  --fixtures /tmp/pr5045-fixtures --output /tmp/pr5045-block-cache.json \
  --rounds 6 --duration 3
```

Use `--cases NAME ...` for subsets and `--order-offset 1` to reverse the starting
arm for repeats. Run the focused sanitizer command below with `--with-block-cache`
to also instrument and run the new block-cache tests.

```sh
python3 scripts/manticore_pr5045/scale_benchmark.py --selfcheck
python3 scripts/manticore_pr5045/scale_benchmark.py BEFORE_SEARCHD TLS_SEARCHD \
  --work /tmp/pr5045-fixtures --output /tmp/pr5045-scale.json \
  --rounds 6 --duration 3
```

Run `scale_diagnose.py DIAGNOSTIC_SEARCHD FIXTURE_DIRECTORY --output COUNTERS_JSON`
after timed tests to measure cache behavior separately. It also derives reader
admissions/query from the known 256 returned stored fields and records disk-chunk
count. `profile_cache.py TLS_SEARCHD SMALL_FIXTURE --output PROFILE_DIRECTORY`
samples dedicated macOS daemons with cache disabled and 128 MiB. These profiling
requests are checked but their rates are excluded from the performance results.

```sh
python3 scripts/manticore_pr5045/benchmark.py --selfcheck
python3 scripts/manticore_pr5045/benchmark.py BEFORE_SEARCHD TLS_SEARCHD \
  --work /tmp/pr5045-fixtures --output /tmp/pr5045-matrix.json \
  --rounds 6 --duration 3
```

The 20-case matrix covers 20k/1M rows, default 16 MiB and disabled block caching,
1/8 clients, 1/64/256 returned rows, count controls, a hot working set, reconnects,
a mixture of four bulk readers and four hot point readers, and a baseline-versus-
itself A/A control. A single-client point workload has 4,096 query
templates; bulk workloads have 64 templates per client, spread across the full
dataset. Each response is checked, including every stored string. Index metadata
is retained. REPLACE/flush and DROP/recreate checks follow timing.

Each paired comparison uses copied disk snapshots, eight server query workers,
identical cache budgets, and alternating sequential arms. Query caching is
disabled. Client processes run on the server host. The harness reports fixed-
concurrency QPS, server CPU/query, and client-observed latency (including JSON
decoding/validation), with raw samples and per-pair changes. It does not measure
maximum sustainable capacity, cold-disk behavior or production traffic.

HTTP connection reuse and docstore-session lifetime are distinct: normal stored-
field SQL queries create/clean up query-scoped docstore sessions even when the
HTTP connection persists. The mixed workload tests short-query interference;
the reconnect case additionally opens a TCP connection for each measured query.
Reconnect traffic is capped at 50 queries/second/client (400 total), so compare
its CPU/query and latency rather than treating its QPS as a capacity result.
The first uncapped attempt exhausted this macOS host's ephemeral ports; that
failure is retained in the raw log and excluded from completed results. No host
TCP settings were changed.

Use `--cases NAME ...` to select a subset, `--order-offset 1` to reverse initial
arm order, and longer `--duration`/`--rounds` for repeats. Retain the initial
negative/control cases when reporting repeat results.

Focused sanitizers instrument docstore, file I/O and the reader tests while
reusing unchanged dependencies; they are not a full-engine sanitizer build:

```sh
python3 scripts/manticore_pr5045/sanitize_readers.py SOURCE BUILD \
  --output /tmp/pr5045-asan --sanitizer address,undefined --repeat 20
python3 scripts/manticore_pr5045/sanitize_readers.py SOURCE BUILD \
  --output /tmp/pr5045-tsan --sanitizer thread --repeat 20
```

`build_diagnostic.py SOURCE BUILD OUTPUT` builds a separate instrumented daemon
that prints reader lookup/hit, insertion/deletion and small-block cache hit/miss
counts at shutdown. Run `diagnose.py DIAGNOSTIC_SEARCHD FIXTURE_DIRECTORY --output
COUNTERS_JSON` with the benchmark's prepared fixtures. Never use this executable
for timing. It verifies that the
large default-cache workload reaches reader lookups; its counters also alter
scheduling and cannot predict exact hit rates in the timed binaries.

Borrowed reader pointers still depend on the existing external session/index
lifetime protection. Tests exercise valid lifetimes, including retirement
between synchronized reads. They do not make concurrent deletion of the reader
currently being used safe.

The existing `support.py` and `sanitize_readers.py` are reused from the original
PR evidence. Measurements and logs are kept locally under
`docs/process/data/manticore-pr5045-20261113/`, following the repository's policy
for raw experiment data. The tracked process report records the results.
