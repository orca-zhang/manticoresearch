# Historical raw evidence, published with English reports

Source: the unchanged local Nov 13 experiment ZIP, SHA256
4293d6ac38251dba987b875d249d5fe1cf53e155ef22ba19302e25109b6cf081.
All raw experiment members retain their original bytes. Three earlier Chinese
narrative reports are omitted and replaced by the current English review reports
under english-reports/. This archive therefore has its own hash and is not a
byte-identical copy of that local source ZIP. The English reports are also
published with working relative links at review/docid-tls/ in the docs branch.

The source SHA256SUMS file is retained as SOURCE_SNAPSHOT_SHA256SUMS, describing
the original snapshot. ARCHIVE_SHA256.json hashes members of this published
archive, excluding itself. Historical block-cache phases have TLS in both arms;
they are not performance measurements of final #5042. Current no-TLS evidence
is in the separate shared-block-cache-evidence.zip.

Omitted narrative paths:
- docs/process/manticore-block-cache-optimization-2026-11-13.md
- docs/process/manticore-pr5045-review-2026-11-13.md
- docs/process/manticore-pr5045-scale-2026-11-13.md
