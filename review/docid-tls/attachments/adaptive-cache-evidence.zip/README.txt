Adaptive docstore cache experiment, 2026-11-13.
Start with review/docid-tls/ADAPTIVE_CACHE_2026-11-13.md.
The archive contains this experiment, not every historical report linked by the guide.
Legacy reports and artifacts remain available from the published repository.
Source commit: ad885be366eda4e897c828f05cb93ff04702d02c.
Entry reclamation is demonstrated; lower process RSS is not.
Binaries, objects, archives, runtime data and allocator dumps are excluded.
