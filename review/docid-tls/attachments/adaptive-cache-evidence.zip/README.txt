Current adaptive docstore cache evidence. Start with review/docid-tls/ADAPTIVE_CACHE_2026-11-13.md.
Contains final default/adaptive measurements and a separate stopped pre-packing diagnostic.
Binaries, objects, archives and runtime data are excluded.
Historical reports/artifacts linked by the guide remain in the published repository.
