# Reader TLS: original and latest block-cache evidence

The current report is TLS_REVIEW_2026-11-13.md; the original-cache narrative
is TLS_ORIGINAL_CACHE_2026-11-13.md. Raw datasets have distinct evidence paths:
`tls/` is original single-LRU/CRC32; `tls-latest-block/` is shared shards/XXH3.
Each pair holds its cache implementation/budget constant and varies reader TLS.

Latest baseline: 376fbf9988b2458ee196a5d92135c35a5121edc7. The TLS candidate adds
only the production reader diff from 019868e9f79d1bb2bd1f96dafb88ef20acd45418.
Native DocID code is disabled in both latest arms. Source/binary hashes,
commands, test/sanitizer logs and every timed sample are retained. Executables
and object files are omitted. ARCHIVE_SHA256.json hashes all members except itself.

The archived benchmark helpers reproduce the two contexts using separate tools;
see repro/2026-11-13/README.md. Other linked project reports/historical downloads
are available online in the evidence branch. #5045 itself remains TLS-only.
