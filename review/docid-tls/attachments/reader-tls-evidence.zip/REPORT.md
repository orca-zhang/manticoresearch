# reader-tls measurements

## 2. TLS on an independent upstream baseline

Primary comparison: upstream `047d2f9` versus the same source plus patch 2.
The DocID prototype is absent from both binaries. Same copied 20k-row disk
snapshot, 128 B stored text, 16 KiB blocks, LZ4, `threads=8`, 1/8 persistent
HTTP connections, four alternating two-second rounds per arm. Every returned
field is checked. Both query plans and binary hashes are captured in the JSON.

**Within every row, both binaries use the same block-cache budget.** The QPS
ratio measures TLS at that budget; it does not compare disabling versus enabling
block caching. QPS change is `median(after)/median(before)-1`. CPU/query change
uses the analogous server CPU ratio.

| Block cache | Clients | Rows | Projection | Before QPS | TLS QPS | QPS change | CPU/query change |
| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| 0 | 1 | 1 | stored text | 8,380 | 8,697 | +3.78% | -1.81% |
| 0 | 1 | 64 | stored text | 2,920 | 2,971 | +1.74% | -1.21% |
| 0 | 1 | 256 | stored text | 1,026 | 1,036 | +0.99% | -1.09% |
| 0 | 1 | 256 | count | 3,607 | 3,537 | -1.94% | -0.86% |
| 0 | 8 | 1 | stored text | 27,849 | 29,801 | +7.01% | -2.80% |
| 0 | 8 | 64 | stored text | 11,543 | 11,603 | +0.52% | -4.03% |
| 0 | 8 | 256 | stored text | 4,049 | 4,336 | +7.09% | -5.20% |
| 0 | 8 | 256 | count | 14,818 | 14,918 | +0.67% | -2.96% |
| 16 MiB | 1 | 1 | stored text | 7,921 | 8,560 | +8.07% | -3.16% |
| 16 MiB | 1 | 64 | stored text | 3,778 | 3,758 | -0.54% | +0.62% |
| 16 MiB | 1 | 256 | stored text | 1,345 | 1,296 | -3.63% | +0.37% |
| 16 MiB | 1 | 256 | count | 3,551 | 3,357 | -5.47% | +1.96% |
| 16 MiB | 8 | 1 | stored text | 33,770 | 35,405 | +4.84% | -1.09% |
| 16 MiB | 8 | 64 | stored text | 10,661 | 10,585 | -0.71% | +0.53% |
| 16 MiB | 8 | 256 | stored text | 2,879 | 2,916 | +1.30% | +1.07% |
| 16 MiB | 8 | 256 | count | 18,136 | 18,660 | +2.89% | +0.75% |

### Targeted repeat and interpretation

The 8-client/256-row/cache-disabled case and count control were repeated with
six alternating three-second rounds per arm, after the main run and without
concurrent builds/tests.

| Projection | Before QPS | TLS QPS | QPS change | CPU/query change |
| --- | ---: | ---: | ---: | ---: |
| stored text | 4,568 | 5,217 | +14.20% | -8.48% |
| count | 16,514 | 16,450 | -0.39% | -0.49% |

The 256-row targeted workload shows a benefit in both runs, but magnitude varies.
The 64-row case is only +0.52% QPS in the primary run, so a stable gain there
is not established. Warm-block-cache and point/count controls vary too; in the
primary run the warm single-client point case is +8.07% and the warm count
case is -5.47%, despite bypassing reader lookups. Do not attribute such controls
to mutex savings or claim universal benefit. These short local samples do not
provide a production confidence interval or a zero-regression guarantee.

The earlier +8.02%–11.24% results came from paired builds with the DocID
prototype enabled at the same budget in both arms. They are retained under
`evidence/reader-tls-m4/` for traceability, but are not the primary independent
upstream claim. Different fixtures/builds/runs cannot quantify the separate
effect of DocID by subtraction.

A separate diagnostic run in that prior combined environment observed 98.59%
of reader lookups avoiding the mutex at eight clients/256 rows with block
caching disabled, and no additional reader lookups after full block-cache
warmup. Those counters were absent from timed binaries; this is a diagnostic
observation with its own scheduling, not an exact lock-hit prediction for the
fresh upstream run.

TLS costs 32 B per OS thread (256 B at eight threads) plus runtime metadata;
the shared generation adds 8 B. Reader ownership, immediate cleanup and the
existing 8 MiB reader-buffer budget remain intact. Cold lookups add checks/TLS
writes; mutation increments invalidate other sessions. No process-memory saving
is claimed. Cache-line padding of this TLS entry is not included.

The packaged raw JSON also records server/client CPU and memory snapshots.
These snapshots are not a controlled RSS study. Clients share the server host;
rates are fixed-concurrency throughput, not maximum sustainable capacity, p99
latency, cold-disk behavior or a production workload mix. Linux TLS SQL QPS and
full Linux engine/SQL tests remain unmeasured.
