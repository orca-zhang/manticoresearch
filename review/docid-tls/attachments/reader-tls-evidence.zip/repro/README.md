# Reproduce the independent TLS comparison

Build and save a searchd from the stated unmodified upstream base. Apply only
the reader-TLS source patch and rebuild searchd/gmanticoretest. Initialize MCL
at the superproject's pinned commit and follow upstream dependency instructions.
Run the full GoogleTest suite, then from this extracted attachment's root:

```sh
python3 repro/bench_reader_tls.py /path/to/before/searchd /path/to/tls/searchd \
  --output /tmp/tls-main.json --block-size 16384 --compression lz4 --rounds 4
python3 repro/bench_reader_tls.py /path/to/before/searchd /path/to/tls/searchd \
  --output /tmp/tls-repeat.json --block-size 16384 --compression lz4 --rounds 6 \
  --duration 3 --concurrency 8 --batches 256 --block-caches 0
```

The standard-library harness has no DocID prototype dependency/setting. Both
arms have identical block-cache budgets inside each case, copied disk data and
query plans. One process per persistent HTTP connection verifies every field.
It records raw QPS, server/client CPU, plans and binary hashes; lifecycle checks
run after timing. Do not run builds/tests/other benchmarks during timing.

For the Apple calibration workaround, prefix the command with
`python3 repro/run_with_calibration.py /path/to/this-build-gtests.log` and give
it the Python benchmark command above. Use this build's supported exports in
both arms; archived values are not portable defaults.

For focused sanitizers with an existing Unix Makefiles engine/test build:

```sh
python3 repro/sanitize_readers.py /path/to/checkout /path/to/build \
  --output /tmp/readers-asan --sanitizer address,undefined --repeat 20
python3 repro/sanitize_readers.py /path/to/checkout /path/to/build \
  --output /tmp/readers-tsan --sanitizer thread --repeat 20
```

These instrument docstore.cpp, fileio.cpp and tests while reusing other engine
objects. They are not full-engine sanitizer coverage. The archived earlier
sanitizer logs state their actual base/source hashes; the portable helper was
syntax/CLI-checked during preparation. Prior combined-prototype SQL samples are
secondary evidence and are distinguished from the independent upstream matrix.
