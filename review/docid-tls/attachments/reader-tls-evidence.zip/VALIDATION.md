# Local validation environment

Base: 047d2f99522d78e0aa1de7e7dc945a9abe1b673a; MCL:
88b5412a243ab0439957203acfe86c09944280d3. Apple M4 Pro, Clang 21,
RelWithDebInfo -O2. MCL_LOCAL_RUNTIME=OFF, dynamic ICU ON;
Galera/MySQL/PostgreSQL/ODBC/Jieba/RE2/Snowball OFF.
Full UberTest/CLT, Windows and Linux full-engine/SQL CI are not covered here.
No production capacity, tail-latency or process-RSS benefit is claimed.

Fresh independent build: 496/496 GoogleTests passed. Five new reader API
tests also passed on the upstream implementation before adding TLS. Exact
SQL/lifecycle checks passed in both paired runs. Earlier focused sanitizer
runs passed all five tests in 20 ASan+UBSan and 20 TSan rounds, instrumenting
docstore.cpp, fileio.cpp and tests while reusing unchanged dependencies.
Those runs use the earlier base with matching module hashes; they are not
full-engine sanitizer coverage.

The full preparation record separately retains a combined-tree first-run JSON
death-test SIGBUS and its 522/522 calibrated rerun. No such failure occurred
in the independent patch validation reported above.
